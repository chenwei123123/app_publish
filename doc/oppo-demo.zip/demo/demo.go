package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
)

var (
	domain        = "https://oop-openapi-cn.heytapmobi.com" //正式环境接口域名
	client_id     = "************"                          //client_id，长度为19
	client_secret = "**************"                        //client_secret，长度为64
	client        = &http.Client{Timeout: 5 * time.Second}
)

func checkError(err error) {
	if err != nil {
		panic(err)
	}
}

func getAccessToken() string {
	// 尝试获取存储的access token
	// 如果存储的access token为空，则调用接口获取access token
	// 接口路由 /developer/v1/token
	// 获取到access token后存储起来
	return "Access Token"
}

// 计算签名
func calSign(key string, data url.Values) string {
	// 将请求参数按key排序
	keys_arr := make([]string, 0, len(data))
	for key := range data {
		keys_arr = append(keys_arr, key)
	}
	sort.Strings(keys_arr)
	// 拼接参数
	sign_arr := make([]string, 0, len(keys_arr))
	for _, key := range keys_arr {
		sign := key + "=" + data.Get(key)
		sign_arr = append(sign_arr, sign)
	}
	sign_str := strings.Join(sign_arr, "&")

	// 进行HmacSHA256计算
	h := hmac.New(sha256.New, []byte(key))
	h.Write([]byte(sign_str))
	res := h.Sum(nil)
	return hex.EncodeToString(res)
}

func main() {
	data := make(url.Values)
	// 公共参数
	data.Set("access_token", getAccessToken())
	data.Set("timestamp", strconv.FormatInt(time.Now().Unix(), 10))
	// 业务参数
	data.Set("pkg_name", "com.foo.bar")
	// 计算签名
	api_sign := calSign(client_secret, data)
	data.Set("api_sign", api_sign)

	// 发起GET请求
	uri := "/resource/v1/app/info" + "?" + data.Encode()
	resp, err := client.Get(domain + uri)
	checkError(err)
	// 若HTTP响应为 405 Method Not Allowed ，说明请求的HTTP方法不正确
	// 具体请求的HTTP方法(GET/POST/...等)，请依照开放平台对应接口文档中标注的方法发起接口调用
	if resp.StatusCode > 400 {
		panic(resp.Status)
	}
	defer resp.Body.Close()
	body, _ := ioutil.ReadAll(resp.Body)
	fmt.Println("Response body:", string(body))
}

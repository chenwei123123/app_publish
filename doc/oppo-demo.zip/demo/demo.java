package com.oppo.openapi.demo;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class Main {

    private static final String CHARSET_UTF8 = "utf-8";

    private static final String requestDomain = "https://oop-openapi-cn.heytapmobi.com";
    private static final String clientId = "**************";
    private static final String accessSecret = "**********************";

    public static void main(String[] args) throws Exception {
        System.out.println(run());
    }

    private static String run() throws IOException {
        Map<String, Object> params = new HashMap<>();
        // 公共参数
        params.put("access_token", getAccessToken());
        params.put("timestamp", System.currentTimeMillis() / 1000);
        // 业务参数
        params.put("pkg_name", "com.foo.bar");
        // 计算签名
        String sign = sign(accessSecret, params);
        params.put("api_sign", sign);
        String requestUrl = requestDomain + "/resource/v1/app/info";
        return sendRequest(requestUrl, params);
    }

    /**
     * 这里可实现获取并存储续期access token的逻辑
     * @return String
     * @throws IOException
     */
    private static String getAccessToken() throws IOException {
        // 尝试获取存储的access token
        // 如果存储的access token为空，则调用接口获取access token
        // 接口路由 /developer/v1/token
        // 获取到access token后存储起来
        return "Access Token";
    }

    /**
     * 对请求参数进行签名
     * @param secret
     * @param paramsMap
     * @return String
     * @throws IOException
     */
    private static String sign(String secret, Map<String, Object> paramsMap)
            throws IOException {
        List keysList = new ArrayList<>(paramsMap.keySet());
        Collections.sort(keysList);
        StringBuilder sb = new StringBuilder();
        List<String> paramList = new ArrayList<>();
        for (Object key : keysList) {
            Object object = paramsMap.get(key);
            if (object == null){
                continue;
            }
            String value = key + "=" + object;
            paramList.add(value);
        }
        String signStr = String.join("&", paramList);
        return hmacSHA256(signStr, secret);
    }

    /**
     * HMAC_SHA256 计算签名
     * @param data 需要加密的参数
     * @param key 签名密钥
     * @return String 返回加密后字符串
     */
    public static String hmacSHA256(String data, String key) {
        try {
            byte[] secretByte = key.getBytes(Charset.forName("UTF-8"));
            SecretKeySpec signingKey = new SecretKeySpec(secretByte, "HmacSHA256");
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            byte[] dataByte = data.getBytes(Charset.forName("UTF-8"));
            byte[] by = mac.doFinal(dataByte);
            return byteArr2HexStr(by);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 字节数组转换为十六进制
     * @param bytes
     * @return String
     */
    private static String byteArr2HexStr(byte[] bytes) {
        int length= bytes.length;
        // 每个byte用两个字符才能表示，所以字符串的长度是数组长度的两倍
        StringBuilder sb = new StringBuilder(length* 2);
        for (int i = 0; i < length; i++) {
            // 将得到的字节转16进制
            String strHex = Integer.toHexString(bytes[i] & 0xFF);
            // 每个字节由两个字符表示，位数不够，高位补0
            sb.append((strHex.length() == 1) ? "0" + strHex : strHex);
        }
        return sb.toString();
    }

    /**
     * 发起普通GET请求
     * 这里的HTTP请求方法仅作调试参考，具体请求方式根据需求进行调整
     * @param requestUrl
     * @param params
     * @return
     * @throws IOException
     */
    private static String sendRequest(String requestUrl, Map<String, Object> params) throws IOException {
        String query = buildQuery(params, CHARSET_UTF8);
        URL url = new URL(requestUrl + "?" + query);

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.setRequestProperty("Host", url.getHost());
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=" + CHARSET_UTF8);
            // 若HTTP响应为 405 Method Not Allowed ，说明请求的HTTP方法不正确
            // 具体请求的HTTP方法(GET/POST/...)，请依照开放平台对应接口文档中标注的方法发起接口调用
            rsp = getResponseToString(conn);
        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        return rsp;
    }

    private static String buildQuery(Map<String, Object> params, String charset) throws IOException {
        if (params == null || params.isEmpty()) {
            return null;
        }

        StringBuilder query = new StringBuilder();
        Set<Entry<String, Object>> entries = params.entrySet();
        boolean hasParam = false;

        for (Entry<String, Object> entry : entries) {
            String name = entry.getKey();
            Object value = entry.getValue();
            // 忽略值为null的参数
            if (value != null) {
                if (hasParam) {
                    query.append("&");
                } else {
                    hasParam = true;
                }
                query.append(name).append("=").append(URLEncoder.encode(String.valueOf(value), charset));
            }
        }

        return query.toString();
    }

    private static String getResponseToString(HttpURLConnection conn) throws IOException {
        String charset = getResponseCharset(conn.getContentType());
        if (conn.getResponseCode() < 400) {
            return getStreamToString(conn.getInputStream(), charset);
        } else {// Client Error 4xx and Server Error 5xx
            throw new IOException(conn.getResponseCode() + " " + conn.getResponseMessage());
        }
    }

    private static String getStreamToString(InputStream stream, String charset) throws IOException {
        try {
            Reader reader = new InputStreamReader(stream, charset);
            StringBuilder response = new StringBuilder();

            final char[] buff = new char[1024];
            int read = 0;
            while ((read = reader.read(buff)) > 0) {
                response.append(buff, 0, read);
            }

            return response.toString();
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }

    private static String getResponseCharset(String ctype) {
        String charset = CHARSET_UTF8;

        if (isNotEmpty(ctype)) {
            String[] params = ctype.split(";");
            for (String param : params) {
                param = param.trim();
                if (param.startsWith("charset")) {
                    String[] pair = param.split("=", 2);
                    if (pair.length == 2) {
                        if (isNotEmpty(pair[1])) {
                            charset = pair[1].trim();
                        }
                    }
                    break;
                }
            }
        }

        return charset;
    }

    private static boolean isNotEmpty(String value) {
        int strLen;
        if (value == null || (strLen = value.length()) == 0) {
            return false;
        }
        for (int i = 0; i < strLen; i++) {
            if ((Character.isWhitespace(value.charAt(i)) == false)) {
                return true;
            }
        }
        return false;
    }
}

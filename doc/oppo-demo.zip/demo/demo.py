import hashlib
import hmac
import json
import time
from urllib import request, parse


class Demo:
    def __init__(self, domain, client_id, client_secret):
        self.__domain = domain
        self.__client_id = client_id
        self.__client_secret = client_secret
        self.run()

    def run(self):
        data = {
            # 公共参数
            "access_token": self.get_access_token(),
            "timestamp": int(time.time()),
            # 业务参数
            "pkg_name": "com.foo.bar",
        }
        # 计算签名
        sign = self.cal_sign(self.__client_secret, data)
        data['api_sign'] = sign
        url = self.__domain + "/resource/v1/app/info"
        self.send_request(url, data)

    # 获取AccessToken
    def get_access_token(self):
        """
        尝试获取存储的access token，
        如果存储的access token为空，则调用接口获取access token。
        接口路由 /developer/v1/token，
        获取到access token后存储起来。
        """
        return "Access Token"

    # 签名方法
    def cal_sign(self, key, data):
        sign_arr = [key + "=" + str(data[key]) for key in sorted(data.keys())]
        sign = '&'.join(sign_arr).encode("utf-8")
        sha256 = hmac.new(key.encode("utf-8"), sign, hashlib.sha256)
        return sha256.hexdigest()

    # 发起GET请求
    def send_request(self, url, data):
        """
        这里的HTTP请求方法仅作调试参考，具体请求方式根据需求进行调整
        :param url:
        :param data:
        :return:
        """
        url += "?" + parse.urlencode(data)
        req = request.Request(url)

        """
        若HTTP响应为 405 Method Not Allowed ，说明请求的HTTP方法不正确
        具体请求的HTTP方法(GET/POST/...等)，请依照开放平台对应接口文档中标注的方法发起接口调用
        """
        with request.urlopen(req) as f:
            res = f.read()
            print(json.loads(res))


if __name__ == "__main__":
    # 请求域名
    domain = "https://oop-openapi-cn.heytapmobi.com"
    # 长度为19为的client_id
    client_id = "**************"
    # 长度为64的client_secret
    client_secret = "*********************"
    Demo(domain, client_id, client_secret)

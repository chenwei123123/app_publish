<?php

new class{
    private $domain = 'https://oop-openapi-cn.heytapmobi.com';
    private $client_id = '**************';//长度为19为的client_id
    private $client_secret = '*********************';//长度为64的client_secret

    public function __construct()
    {
        $this->run();
    }

    public function run()
    {
        $data = [
            // 公共参数
            'access_token' => $this->getAccessToken(),
            'timestamp' => time(),
            // 业务参数
            'pkg_name' => 'com.foo.bar',
        ];
        // 计算签名
        $sign = $this->sign($this->client_secret, $data);
        $data['api_sign'] = $sign;
        // 在此处调用业务接口
        $response = $this->sendRequest('GET', '/resource/v1/app/info', $data);
        print_r('Response body:' . $response);
    }

    /**
     * 获取access token
     * @return string|null
     */
    public function getAccessToken():?string
    {
        // 尝试获取存储的access token
        // 如果存储的access token为空，则调用接口获取access token
        // 接口路由 /developer/v1/token
        // 获取到access token后存储起来
        return "Access Token";
    }

    /**
     * 签名方法
     * @param string $secret
     * @param array $data
     * @return string
     */
    public function sign(string $secret, array $data):string
    {
        ksort($data);
        $sign_array = array();
        foreach ($data as $key => $val){
            $sign_array[] = $key . '=' . $val;
        }
        $sign_string = join('&', $sign_array);
        $sign = hash_hmac('sha256', $sign_string, $secret, true);
        $sign = bin2hex($sign);
        return $sign;
    }

    /**
     * 这里的HTTP请求方法仅作调试参考，具体请求方式根据需求进行调整
     * @param $method
     * @param $uri
     * @param array $data
     * @return mixed
     * @throws Exception
     */
    public function sendRequest($method, $uri, $data = [])
    {
        $curl = curl_init();
        $option = [
            CURLOPT_URL => $this->domain . $uri,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT_MS => 20000,
        ];
        switch (strtoupper($method)){
            case "GET":
                $uri .= '?' . http_build_query($data);
                $option[CURLOPT_URL] = $this->domain . $uri;
                break;
            case "POST":
                $option[CURLOPT_POST] = true;
                $option[CURLOPT_POSTFIELDS] = http_build_query($data);
                break;
        }
        curl_setopt_array($curl, $option);
        $res = curl_exec($curl);
        if (!$res){
            throw new \Exception(curl_error($curl), curl_errno($curl));
        }
        $info = curl_getinfo($curl);
        // 若HTTP响应为 405 Method Not Allowed ，说明请求的HTTP方法不正确
        // 具体请求的HTTP方法(GET/POST/...等)，请依照开放平台对应接口文档中标注的方法发起接口调用
        if ($info['http_code'] > 400){
            throw new \Exception('Http response code is '.$info['http_code'], $info['http_code']);
        }
        return $res;
    }
};
